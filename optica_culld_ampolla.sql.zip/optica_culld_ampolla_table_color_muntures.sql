
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `color_muntures`
--

CREATE TABLE `color_muntures` (
  `id_colormuntura` int(11) NOT NULL,
  `colors_d_color` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `color_muntures`
--

INSERT INTO `color_muntures` (`id_colormuntura`, `colors_d_color`) VALUES
(1, 1),
(2, 3);
