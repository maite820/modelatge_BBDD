
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `comandes_venda`
--

CREATE TABLE `comandes_venda` (
  `id_comandavenda` int(11) NOT NULL,
  `data` date DEFAULT NULL,
  `quantitat` int(11) DEFAULT NULL,
  `total` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `comandes_venda`
--

INSERT INTO `comandes_venda` (`id_comandavenda`, `data`, `quantitat`, `total`) VALUES
(1, '2020-10-06', 1, 100),
(2, '2020-10-11', 2, 200);
