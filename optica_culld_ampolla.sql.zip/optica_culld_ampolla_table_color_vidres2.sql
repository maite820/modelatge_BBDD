
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `color_vidres2`
--

CREATE TABLE `color_vidres2` (
  `id_colorvidre2` int(11) NOT NULL,
  `colors_d_color1` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `color_vidres2`
--

INSERT INTO `color_vidres2` (`id_colorvidre2`, `colors_d_color1`) VALUES
(1, 0),
(2, 0);
