
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ulleres`
--

CREATE TABLE `ulleres` (
  `id_ullera` int(11) NOT NULL,
  `marca` varchar(25) DEFAULT NULL,
  `graduacio_vidres` varchar(45) DEFAULT NULL,
  `preu` float DEFAULT NULL,
  `tipus_muntura_copy1_id_tipusmuntura` int(11) NOT NULL,
  `color_muntures_id_colormuntura` int(11) NOT NULL,
  `color_vidres1_id_colorvidre1` int(11) NOT NULL,
  `color_vidres2_id_colorvidre2` int(11) NOT NULL,
  `proveidors_id_proveidor` int(11) NOT NULL,
  `comandes_venda_id_comandavenda` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `ulleres`
--

INSERT INTO `ulleres` (`id_ullera`, `marca`, `graduacio_vidres`, `preu`, `tipus_muntura_copy1_id_tipusmuntura`, `color_muntures_id_colormuntura`, `color_vidres1_id_colorvidre1`, `color_vidres2_id_colorvidre2`, `proveidors_id_proveidor`, `comandes_venda_id_comandavenda`) VALUES
(1, 'michael kors', '1/1', 75, 3, 2, 1, 1, 1, 1);
