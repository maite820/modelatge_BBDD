
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `proveidors`
--

CREATE TABLE `proveidors` (
  `id_proveidor` int(11) NOT NULL,
  `nom_proveidor` varchar(45) DEFAULT NULL,
  `telefon` varchar(15) DEFAULT NULL,
  `fax` varchar(15) DEFAULT NULL,
  `NIF` varchar(10) DEFAULT NULL,
  `adreces_usuari_id_adreça` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `proveidors`
--

INSERT INTO `proveidors` (`id_proveidor`, `nom_proveidor`, `telefon`, `fax`, `NIF`, `adreces_usuari_id_adreça`) VALUES
(1, 'ulleres blanc,s.l.', '987456654', '987666444', 'b-34563838', 3),
(2, 'ulleres retro,s.a.', '93456666', '934546765', 'A-3454444', 1);
