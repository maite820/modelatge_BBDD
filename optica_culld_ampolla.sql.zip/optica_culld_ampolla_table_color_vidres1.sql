
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `color_vidres1`
--

CREATE TABLE `color_vidres1` (
  `id_colorvidre1` int(11) NOT NULL,
  `colors_d_color` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `color_vidres1`
--

INSERT INTO `color_vidres1` (`id_colorvidre1`, `colors_d_color`) VALUES
(2, 3),
(1, 4);
