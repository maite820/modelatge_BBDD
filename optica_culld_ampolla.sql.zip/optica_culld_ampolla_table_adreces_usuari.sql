
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `adreces_usuari`
--

CREATE TABLE `adreces_usuari` (
  `id_adreça` int(11) NOT NULL,
  `carrer` varchar(45) DEFAULT NULL,
  `número` int(11) DEFAULT NULL,
  `pis` int(11) DEFAULT NULL,
  `porta` int(11) DEFAULT NULL,
  `ciutat` varchar(25) DEFAULT NULL,
  `codi postal` int(11) DEFAULT NULL,
  `pais` varchar(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `adreces_usuari`
--

INSERT INTO `adreces_usuari` (`id_adreça`, `carrer`, `número`, `pis`, `porta`, `ciutat`, `codi postal`, `pais`) VALUES
(1, 'republica', 14, 1, 1, 'sabadell', 8201, 'espanya'),
(2, 'girona', 24, 3, 3, 'barcelona', 6754, 'espanya'),
(3, 'salamanca', 345, 3, 1, 'lugo', 26345, 'espanya');
