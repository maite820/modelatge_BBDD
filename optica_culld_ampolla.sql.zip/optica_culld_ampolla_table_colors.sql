
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `colors`
--

CREATE TABLE `colors` (
  `d_color` int(11) NOT NULL,
  `color` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `colors`
--

INSERT INTO `colors` (`d_color`, `color`) VALUES
(1, 'vermell'),
(2, 'blau'),
(3, 'negre'),
(4, 'verd');
