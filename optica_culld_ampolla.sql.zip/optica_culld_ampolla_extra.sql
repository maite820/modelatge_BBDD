
--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `adreces_usuari`
--
ALTER TABLE `adreces_usuari`
  ADD PRIMARY KEY (`id_adreça`);

--
-- Indices de la tabla `clients`
--
ALTER TABLE `clients`
  ADD PRIMARY KEY (`id_client`),
  ADD KEY `fk_clients_adreces_usuari1_idx` (`adreces_usuari_id_adreça`);

--
-- Indices de la tabla `colors`
--
ALTER TABLE `colors`
  ADD PRIMARY KEY (`d_color`);

--
-- Indices de la tabla `color_muntures`
--
ALTER TABLE `color_muntures`
  ADD PRIMARY KEY (`id_colormuntura`),
  ADD KEY `fk_color_muntures_colors1_idx` (`colors_d_color`);

--
-- Indices de la tabla `color_vidres1`
--
ALTER TABLE `color_vidres1`
  ADD PRIMARY KEY (`id_colorvidre1`),
  ADD KEY `fk_color_vidres1_colors1_idx` (`colors_d_color`);

--
-- Indices de la tabla `color_vidres2`
--
ALTER TABLE `color_vidres2`
  ADD PRIMARY KEY (`id_colorvidre2`),
  ADD KEY `fk_color_vidres2_colors1_idx` (`colors_d_color1`);

--
-- Indices de la tabla `comandes_venda`
--
ALTER TABLE `comandes_venda`
  ADD PRIMARY KEY (`id_comandavenda`);

--
-- Indices de la tabla `empleats`
--
ALTER TABLE `empleats`
  ADD PRIMARY KEY (`id_empleat`),
  ADD UNIQUE KEY `id_empleat_UNIQUE` (`id_empleat`),
  ADD KEY `fk_empleats_comandes_venda1_idx` (`comandes_venda_id_comandavenda`);

--
-- Indices de la tabla `proveidors`
--
ALTER TABLE `proveidors`
  ADD PRIMARY KEY (`id_proveidor`),
  ADD UNIQUE KEY `id_proveidor_UNIQUE` (`id_proveidor`),
  ADD UNIQUE KEY `NIF_UNIQUE` (`NIF`),
  ADD KEY `fk_proveidors_adreces_usuari_idx` (`adreces_usuari_id_adreça`);

--
-- Indices de la tabla `tipus_muntures`
--
ALTER TABLE `tipus_muntures`
  ADD PRIMARY KEY (`id_tipusmuntura`);

--
-- Indices de la tabla `ulleres`
--
ALTER TABLE `ulleres`
  ADD KEY `fk_Ulleres_tipus_muntura_copy11_idx` (`tipus_muntura_copy1_id_tipusmuntura`),
  ADD KEY `fk_Ulleres_color_muntures1_idx` (`color_muntures_id_colormuntura`),
  ADD KEY `fk_Ulleres_color_vidres11_idx` (`color_vidres1_id_colorvidre1`),
  ADD KEY `fk_Ulleres_color_vidres21_idx` (`color_vidres2_id_colorvidre2`),
  ADD KEY `fk_Ulleres_proveidors1_idx` (`proveidors_id_proveidor`),
  ADD KEY `fk_Ulleres_comandes_venda1_idx` (`comandes_venda_id_comandavenda`);

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `clients`
--
ALTER TABLE `clients`
  ADD CONSTRAINT `fk_clients_adreces_usuari1` FOREIGN KEY (`adreces_usuari_id_adreça`) REFERENCES `adreces_usuari` (`id_adreça`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `color_muntures`
--
ALTER TABLE `color_muntures`
  ADD CONSTRAINT `fk_color_muntures_colors1` FOREIGN KEY (`colors_d_color`) REFERENCES `colors` (`d_color`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `color_vidres1`
--
ALTER TABLE `color_vidres1`
  ADD CONSTRAINT `fk_color_vidres1_colors1` FOREIGN KEY (`colors_d_color`) REFERENCES `colors` (`d_color`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `color_vidres2`
--
ALTER TABLE `color_vidres2`
  ADD CONSTRAINT `fk_color_vidres2_colors1` FOREIGN KEY (`colors_d_color1`) REFERENCES `colors` (`d_color`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `empleats`
--
ALTER TABLE `empleats`
  ADD CONSTRAINT `fk_empleats_comandes_venda1` FOREIGN KEY (`comandes_venda_id_comandavenda`) REFERENCES `comandes_venda` (`id_comandavenda`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `proveidors`
--
ALTER TABLE `proveidors`
  ADD CONSTRAINT `fk_proveidors_adreces_usuari` FOREIGN KEY (`adreces_usuari_id_adreça`) REFERENCES `adreces_usuari` (`id_adreça`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `ulleres`
--
ALTER TABLE `ulleres`
  ADD CONSTRAINT `fk_Ulleres_color_muntures1` FOREIGN KEY (`color_muntures_id_colormuntura`) REFERENCES `color_muntures` (`id_colormuntura`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_Ulleres_color_vidres11` FOREIGN KEY (`color_vidres1_id_colorvidre1`) REFERENCES `color_vidres1` (`id_colorvidre1`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_Ulleres_color_vidres21` FOREIGN KEY (`color_vidres2_id_colorvidre2`) REFERENCES `color_vidres2` (`id_colorvidre2`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_Ulleres_comandes_venda1` FOREIGN KEY (`comandes_venda_id_comandavenda`) REFERENCES `comandes_venda` (`id_comandavenda`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_Ulleres_proveidors1` FOREIGN KEY (`proveidors_id_proveidor`) REFERENCES `proveidors` (`id_proveidor`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_Ulleres_tipus_muntura_copy11` FOREIGN KEY (`tipus_muntura_copy1_id_tipusmuntura`) REFERENCES `tipus_muntures` (`id_tipusmuntura`) ON DELETE NO ACTION ON UPDATE NO ACTION;
