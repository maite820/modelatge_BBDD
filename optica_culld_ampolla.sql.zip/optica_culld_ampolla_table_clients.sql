
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `clients`
--

CREATE TABLE `clients` (
  `id_client` int(11) NOT NULL,
  `nom_client` varchar(45) DEFAULT NULL,
  `telefon` varchar(15) DEFAULT NULL,
  `email` varchar(25) DEFAULT NULL,
  `data_inici` date DEFAULT NULL,
  `id_clientrecomant` int(11) DEFAULT NULL,
  `adreces_usuari_id_adreça` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `clients`
--

INSERT INTO `clients` (`id_client`, `nom_client`, `telefon`, `email`, `data_inici`, `id_clientrecomant`, `adreces_usuari_id_adreça`) VALUES
(1, 'luciano bcn,s.l.', '934563434', 'luciano@gmail.com', '2020-10-05', NULL, 2),
(2, 'entrepans miguel s.l.', '934445676', 'emiguel@gmail.com', '2020-10-13', NULL, 1);
