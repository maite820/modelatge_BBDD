
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipus_muntures`
--

CREATE TABLE `tipus_muntures` (
  `id_tipusmuntura` int(11) NOT NULL,
  `muntura` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `tipus_muntures`
--

INSERT INTO `tipus_muntures` (`id_tipusmuntura`, `muntura`) VALUES
(1, 'flotant'),
(2, 'pasta'),
(3, 'metàl.lica');
